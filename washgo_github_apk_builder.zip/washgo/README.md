# WashGo – Doorstep Car Wash Android MVP

WashGo is a Flutter starter app for customers to browse wash packages and create doorstep car-wash bookings.

## Build an APK automatically with GitHub Actions

1. Create a GitHub account (if needed) and a new repository named `washgo`.
2. Upload the contents of this project ZIP to that repository (keep `.github/workflows/build-apk.yml`).
3. Push the files to the `main` or `master` branch.
4. Open the repository's **Actions** tab. The **Build WashGo Android APK** workflow runs automatically.
5. Open the completed workflow run, scroll to **Artifacts**, and download **WashGo-Android-APK**.
6. Extract the artifact ZIP; it contains `app-release.apk`. Transfer it to your Android phone and install it. You may need to allow installation from your browser/file manager when Android prompts you.

You can also run the workflow manually from **Actions → Build WashGo Android APK → Run workflow**.

## Local build (optional)
Install Flutter SDK and Android Studio, then run:

```bash
flutter create --platforms=android --project-name=washgo .  # only if android/ is missing
flutter pub get
flutter build apk --release
```
APK output: `build/app/outputs/flutter-apk/app-release.apk`

## Current MVP
- Home and service package screens
- Basic Wash, Interior Cleaning, Premium Wash, Full Detailing
- Booking form (vehicle, date/time, address)
- In-memory booking list/history
- Customer profile screen/navigation

## Current limitations
- Bookings are local/in-memory only and reset when the app is restarted.
- No Firebase/backend, OTP login, online payment, live tracking, or admin/staff portal yet.
- The workflow builds an unsigned release APK suitable for testing/sideloading; Play Store release signing is not configured.
