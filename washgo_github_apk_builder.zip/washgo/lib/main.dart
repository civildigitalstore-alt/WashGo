import 'package:flutter/material.dart';

void main() => runApp(const WashGoApp());


class WashGoApp extends StatelessWidget {
  const WashGoApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'WashGo', debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true, scaffoldBackgroundColor: const Color(0xFFF4F7FA),
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF13B8C9), primary: const Color(0xFF13B8C9)),
      fontFamily: 'Roboto'),
    home: const WashGoHome(),
  );
}


class WashService {
  final String name, subtitle, duration;
  final int price;
  final IconData icon;
  const WashService(this.name, this.subtitle, this.duration, this.price, this.icon);
}


class Booking {
  final WashService service;
  final String vehicle, date, time, address;
  Booking(this.service, this.vehicle, this.date, this.time, this.address);
}


class WashGoHome extends StatefulWidget {
  const WashGoHome({super.key});
  @override
  State<WashGoHome> createState() => _WashGoHomeState();
}


class _WashGoHomeState extends State<WashGoHome> {
  int tab = 0;
  final List<Booking> bookings = [];
  final services = const [
    WashService('Basic Wash', 'Exterior foam wash & wipe', '30 min', 299, Icons.water_drop_outlined),
    WashService('Interior Cleaning', 'Vacuum & dashboard cleaning', '45 min', 499, Icons.cleaning_services_outlined),
    WashService('Premium Wash', 'Exterior, interior & tyre shine', '60 min', 699, Icons.auto_awesome),
    WashService('Full Detailing', 'Deep clean & premium detailing', '2–3 hrs', 1999, Icons.local_car_wash),
  ];
  @override
  Widget build(BuildContext context) {
    final pages = [homePage(), servicePage(), bookingPage(), profilePage()];
    return Scaffold(
      body: SafeArea(child: pages[tab]),
      bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.water_drop_outlined), label: 'Services'),
          NavigationDestination(icon: Icon(Icons.calendar_month_outlined), label: 'Bookings'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profile'),
        ]),
    );
  }
  Widget homePage() => ListView(padding: const EdgeInsets.all(20), children: [
    Row(children: [const Icon(Icons.location_on_outlined, color: Color(0xFF13B8C9)), const SizedBox(width: 6),
      const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('SERVICE LOCATION', style: TextStyle(fontSize: 11, color: Colors.grey)), Text('Your doorstep', style: TextStyle(fontWeight: FontWeight.bold))])),
      IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none))]),
    const SizedBox(height: 14),
    Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(color: const Color(0xFF0B2038), borderRadius: BorderRadius.circular(24)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('YOUR CAR,\nFRESH & CLEAN.', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: Colors.white, height: 1.1)),
        const SizedBox(height: 10), const Text('Premium car wash at your doorstep.', style: TextStyle(color: Color(0xFFB7D4E9))),
        const SizedBox(height: 18), FilledButton(onPressed: () => setState(() => tab = 1), child: const Text('Book a Wash  →')),
      ])),
    const SizedBox(height: 24),
    const Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('Our Services', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), Text('Clean made easy')]),
    const SizedBox(height: 12), ...services.take(3).map(serviceCard),
    const SizedBox(height: 14), Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: const Color(0xFFE1F7F8), borderRadius: BorderRadius.circular(18)),
      child: const Row(children: [Icon(Icons.verified_user_outlined, color: Color(0xFF087D8A)), SizedBox(width: 10), Expanded(child: Text('Professional care • Convenient booking • Quality cleaning', style: TextStyle(fontWeight: FontWeight.w600)))])),
  ]);
  Widget servicePage() => ListView(padding: const EdgeInsets.all(20), children: [
    const Text('Choose Your Wash', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), const SizedBox(height: 6),
    const Text('Select the service that fits your vehicle.', style: TextStyle(color: Colors.grey)), const SizedBox(height: 16), ...services.map(serviceCard),
  ]);
  Widget serviceCard(WashService service) => Card(color: Colors.white, elevation: 0, margin: const EdgeInsets.only(bottom: 12), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
    child: Padding(padding: const EdgeInsets.all(16), child: Row(children: [
      Container(width: 54, height: 54, decoration: BoxDecoration(color: const Color(0xFFE5F8FA), borderRadius: BorderRadius.circular(16)), child: Icon(service.icon, color: const Color(0xFF0B8E9D), size: 27)),
      const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(service.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)), Text(service.subtitle, style: const TextStyle(color: Colors.grey, fontSize: 12)), const SizedBox(height: 5), Text(service.duration, style: const TextStyle(fontSize: 12))])),
      Column(crossAxisAlignment: CrossAxisAlignment.end, children: [Text('₹${service.price}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)), const SizedBox(height: 5), FilledButton.tonal(onPressed: () => openBooking(service), child: const Text('Book'))]),
    ])));
  Widget bookingPage() => ListView(padding: const EdgeInsets.all(20), children: [
    const Text('My Bookings', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), const SizedBox(height: 16),
    if (bookings.isEmpty) Container(padding: const EdgeInsets.all(28), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)), child: const Column(children: [Icon(Icons.calendar_today_outlined, size: 50, color: Color(0xFF13B8C9)), SizedBox(height: 12), Text('No bookings yet', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)), SizedBox(height: 6), Text('Your car wash bookings will appear here.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey))]))
    else ...bookings.reversed.map((b) => Card(color: Colors.white, elevation: 0, child: ListTile(leading: const Icon(Icons.local_car_wash, color: Color(0xFF13B8C9)), title: Text(b.service.name), subtitle: Text('${b.vehicle} • ${b.date} • ${b.time}\n${b.address}'), isThreeLine: true, trailing: Text('₹${b.service.price}', style: const TextStyle(fontWeight: FontWeight.bold))))),
    const SizedBox(height: 16), if (bookings.isEmpty) FilledButton(onPressed: () => setState(() => tab = 1), child: const Text('Book Your First Wash')),
  ]);
  Widget profilePage() => ListView(padding: const EdgeInsets.all(20), children: [
    const Text('My Profile', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), const SizedBox(height: 18),
    const CircleAvatar(radius: 42, backgroundColor: Color(0xFFE3F6F8), child: Icon(Icons.person, size: 44, color: Color(0xFF118A98))), const SizedBox(height: 12),
    const Center(child: Text('WashGo Customer', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18))), const SizedBox(height: 20),
    profileItem(Icons.directions_car_outlined, 'My Vehicles'), profileItem(Icons.location_on_outlined, 'Saved Addresses'), profileItem(Icons.payment_outlined, 'Payment Methods'), profileItem(Icons.help_outline, 'Help & Support'), profileItem(Icons.info_outline, 'About WashGo'),
  ]);
  Widget profileItem(IconData icon, String title) => Card(color: Colors.white, elevation: 0, child: ListTile(leading: Icon(icon, color: const Color(0xFF13B8C9)), title: Text(title), trailing: const Icon(Icons.chevron_right)));
  Future<void> openBooking(WashService service) async {
    final vehicleController = TextEditingController();
    final dateController = TextEditingController();
    final timeController = TextEditingController();
    final addressController = TextEditingController();
    final formKey = GlobalKey<FormState>();
    final result = await showDialog<bool>(context: context, builder: (context) => AlertDialog(
      title: Text('Book ${service.name}'), content: SizedBox(width: 420, child: Form(key: formKey, child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextFormField(controller: vehicleController, decoration: const InputDecoration(labelText: 'Vehicle (e.g. Swift, TN 01 AB 1234)'), validator: (v) => v == null || v.isEmpty ? 'Enter vehicle details' : null),
        TextFormField(controller: dateController, decoration: const InputDecoration(labelText: 'Date (e.g. 22 Nov 2026)'), validator: (v) => v == null || v.isEmpty ? 'Enter booking date' : null),
        TextFormField(controller: timeController, decoration: const InputDecoration(labelText: 'Preferred time (e.g. 10:00 AM)'), validator: (v) => v == null || v.isEmpty ? 'Enter preferred time' : null),
        TextFormField(controller: addressController, decoration: const InputDecoration(labelText: 'Service address'), validator: (v) => v == null || v.isEmpty ? 'Enter address' : null),
      ])))), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')), FilledButton(onPressed: () { if (formKey.currentState!.validate()) Navigator.pop(context, true); }, child: const Text('Confirm Booking'))]));
    if (result == true) setState(() { bookings.add(Booking(service, vehicleController.text, dateController.text, timeController.text, addressController.text)); tab = 2; });
    vehicleController.dispose(); dateController.dispose(); timeController.dispose(); addressController.dispose();
  }
}
